exports.uri = {
    local: "mongodb://user:password@mongo:27017",
	atlas: "mongodb+srv://admin:dOaFBLUsN5fU7SCG@cluster0.osryt.mongodb.net"
};
